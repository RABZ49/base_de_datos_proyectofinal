const mysql = require('mysql2'); 

function mostrarEstadios() {
  // Realizar la conexión a la base de datos
  const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'UTPL2023',
    database: 'db_practicum_pm'
  });

  // Realizar la consulta a la base de datos (usando promesas)
  connection.query(consultaSQL).then((results) => {
    // Limpiar el contenido de la tabla antes de agregar nuevos datos
    const tablaResultados = document.getElementById('estadiosTable').getElementsByTagName('tbody')[0];
    tablaResultados.innerHTML = '';

    // Al obtener los resultados:
    results.forEach((estadio) => {
      const fila = document.createElement('tr');
      // Crear las celdas con los datos del estadio
      const celdaId = document.createElement('td');
      celdaId.textContent = estadio.stadium_id;
      fila.appendChild(celdaId);

      const celdaNombre = document.createElement('td');
      celdaNombre.textContent = estadio.stadium_name;
      fila.appendChild(celdaNombre);

      // ... (crear celdas para las demás columnas)

      tablaResultados.appendChild(fila);
    });
  }).catch((error) => {
    // Manejar el error de la consulta
    console.error('Error al obtener los datos:', error);
  }).finally(() => {
    // Cerrar la conexión a la base de datos
    connection.end();
  });
}

// Reemplazar "consultaSQL" con la consulta real
const consultaSQL = `
SELECT
  s.stadium_id,
  s.stadium_name,
  s.city_name,
  s.country_name,
  s.stadium_capacity,
  COUNT(m.match_id) AS matches_played
FROM
  Stadiums s
LEFT JOIN
  Matches m ON s.stadium_id = m.stadium_id
GROUP BY
  s.stadium_id, s.stadium_name, s.city_name, s.country_name, s.stadium_capacity
ORDER BY
  matches_played DESC
LIMIT 5;
`;

// Iniciar la carga de datos al cargar la página
$(document).ready(() => {
  mostrarEstadios();
});


function abrir3() {
  document.getElementById('vent3').style.display = "block";
}

function cerrar3() {
document.getElementById('vent3').style.display = "none"; 
}

function abrir() {
document.getElementById('miPopup').style.display = "block";
}

function cerrar() {
document.getElementById('miPopup').style.display = "none"; 
}

function abrir2() {
document.getElementById('vent2').style.display = "block";
}

function cerrar2() {
document.getElementById('vent2').style.display = "none"; 
}

// Importa las bibliotecas necesarias
const express = require('express');
const mysql = require('mysql2');

const app = express();
const port = 3000;

// Configura la conexión a la base de datos
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'UTPL2023',
    database: 'db_practicum_pm'
});

// Ruta para la consulta de estadios
app.get('/api/estadios', (req, res) => {
    const consultaSQL = `
        SELECT
            s.stadium_id,
            s.stadium_name,
            s.city_name,
            s.country_name,
            s.stadium_capacity,
            COUNT(m.match_id) AS matches_played
        FROM
            Stadiums s
        LEFT JOIN
            Matches m ON s.stadium_id = m.stadium_id
        GROUP BY
            s.stadium_id, s.stadium_name, s.city_name, s.country_name, s.stadium_capacity
        ORDER BY
            matches_played DESC
        LIMIT 5;
    `;

    connection.query(consultaSQL, (error, results) => {
        if (error) {
            return res.status(500).json({ error: 'Error en la consulta de estadios.' });
        }

        res.json(results);
    });
});

// Inicia el servidor
app.listen(port, () => {
    console.log(`Servidor escuchando en http://localhost:${port}`);
});
